create function trigger_on_kullanici_kart_merge() returns trigger
    language plpgsql
as
$$
begin
    update kullanicilar
    set kart_id = new.id
	where new.sahip_id = id;
    return new;
end;
$$;

alter function trigger_on_kullanici_kart_merge() owner to postgres;

