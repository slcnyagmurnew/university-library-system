create function trigger_on_odunc_rezerve_mi_false() returns trigger
    language plpgsql
as
$$
begin
    UPDATE odunc
	SET reserve_mi = 'false'
	WHERE old.materyal_id = obje_id;
    return new;
end;
$$;

alter function trigger_on_odunc_rezerve_mi_false() owner to postgres;

