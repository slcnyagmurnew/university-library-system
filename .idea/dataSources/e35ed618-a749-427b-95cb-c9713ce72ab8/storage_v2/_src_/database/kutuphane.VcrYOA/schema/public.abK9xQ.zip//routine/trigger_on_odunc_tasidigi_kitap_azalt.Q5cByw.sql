create function trigger_on_odunc_tasidigi_kitap_azalt() returns trigger
    language plpgsql
as
$$
begin
   	update kullanicilar
	set tasidigi_kitap_adet = tasidigi_kitap_adet - 1
	where id = old.alan_id;
    return new;
end;
$$;

alter function trigger_on_odunc_tasidigi_kitap_azalt() owner to postgres;

