create function trigger_on_kullanici_kart_update() returns trigger
    language plpgsql
as
$$
begin
	update kullanicilar
	set kart_id = new.id
	where id = new.sahip_id;
    return new;
end;
$$;

alter function trigger_on_kullanici_kart_update() owner to postgres;

