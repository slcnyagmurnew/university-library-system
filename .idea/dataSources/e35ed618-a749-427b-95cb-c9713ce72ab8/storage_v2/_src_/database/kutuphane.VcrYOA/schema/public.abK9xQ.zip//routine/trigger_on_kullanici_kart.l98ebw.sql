create function trigger_on_kullanici_kart() returns trigger
    language plpgsql
as
$$
begin
    insert into kart
    select nextval('kart_id_seq'),new.id,new.id;
    return new;
end;
$$;

alter function trigger_on_kullanici_kart() owner to postgres;

