create function trigger_on_kutuphanede_mi_true() returns trigger
    language plpgsql
as
$$
begin
    update envanter
    set kutuphanede_mi = 'true'
	where id = old.obje_id;
    return new;
end;
$$;

alter function trigger_on_kutuphanede_mi_true() owner to postgres;

