create function trigger_on_odunc_teslim_tarihi() returns trigger
    language plpgsql
as
$$
declare 
	tur_kategori kullanicilar.kategori%TYPE;
	odunc_vakti sinirlar.gun_hakki%TYPE;	
begin
	select kategori INTO tur_kategori FROM kullanicilar WHERE id=new.alan_id;
	select gun_hakki INTO odunc_vakti FROM sinirlar WHERE kategori = tur_kategori;
  	update odunc
	set teslim_tarihi = new.odunc_alinan_tarih + odunc_vakti
	where new.obje_id = obje_id;
    return new;
end;
$$;

alter function trigger_on_odunc_teslim_tarihi() owner to postgres;

