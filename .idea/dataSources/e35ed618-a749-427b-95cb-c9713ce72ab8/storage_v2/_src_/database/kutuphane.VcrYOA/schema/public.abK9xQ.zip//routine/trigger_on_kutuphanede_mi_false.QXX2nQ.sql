create function trigger_on_kutuphanede_mi_false() returns trigger
    language plpgsql
as
$$
begin
    update envanter
    set kutuphanede_mi = 'false'
	where new.obje_id = id;
    return new;
end;
$$;

alter function trigger_on_kutuphanede_mi_false() owner to postgres;

