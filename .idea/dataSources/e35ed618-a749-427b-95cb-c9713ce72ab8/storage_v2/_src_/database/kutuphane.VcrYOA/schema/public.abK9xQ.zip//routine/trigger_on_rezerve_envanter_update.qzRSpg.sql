create function trigger_on_rezerve_envanter_update() returns trigger
    language plpgsql
as
$$
begin
    update rezerve
	set materyal_id = new.id
	where old.id = materyal_id;
    return new;
end;
$$;

alter function trigger_on_rezerve_envanter_update() owner to postgres;

