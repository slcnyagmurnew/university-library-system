create function trigger_on_rezerve_odunc_tarih() returns trigger
    language plpgsql
as
$$
begin
    update rezerve
	set teslim_edildi_tarih = CURRENT_DATE,
	kac_gun_kaldi = 5,
	rezerve_bitecek_tarih = CURRENT_DATE + 5
	where materyal_id = old.obje_id;
    return new;
end;
$$;

alter function trigger_on_rezerve_odunc_tarih() owner to postgres;

