create function trigger_on_odunc_rezerve_mi_true() returns trigger
    language plpgsql
as
$$
begin
   	update odunc
	set reserve_mi = 'true'
	where new.materyal_id = obje_id;
    return new;
end;
$$;

alter function trigger_on_odunc_rezerve_mi_true() owner to postgres;

