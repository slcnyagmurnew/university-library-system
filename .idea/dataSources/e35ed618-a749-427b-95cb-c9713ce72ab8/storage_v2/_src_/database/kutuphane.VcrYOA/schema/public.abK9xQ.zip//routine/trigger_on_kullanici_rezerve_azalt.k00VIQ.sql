create function trigger_on_kullanici_rezerve_azalt() returns trigger
    language plpgsql
as
$$
begin
    UPDATE kullanicilar
	SET rezerve_kitap_adet = rezerve_kitap_adet - 1
	WHERE old.kime_gidecek_id = id;
    return old;
end;
$$;

alter function trigger_on_kullanici_rezerve_azalt() owner to postgres;

