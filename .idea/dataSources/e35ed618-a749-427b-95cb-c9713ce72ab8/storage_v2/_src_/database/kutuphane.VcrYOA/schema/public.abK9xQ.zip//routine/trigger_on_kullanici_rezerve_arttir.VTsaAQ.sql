create function trigger_on_kullanici_rezerve_arttir() returns trigger
    language plpgsql
as
$$
begin
    UPDATE kullanicilar
	SET rezerve_kitap_adet = rezerve_kitap_adet + 1
	WHERE new.kime_gidecek_id = id;
    return new;
end;
$$;

alter function trigger_on_kullanici_rezerve_arttir() owner to postgres;

