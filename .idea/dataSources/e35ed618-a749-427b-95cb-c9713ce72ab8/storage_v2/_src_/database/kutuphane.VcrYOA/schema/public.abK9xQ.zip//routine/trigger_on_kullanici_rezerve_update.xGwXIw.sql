create function trigger_on_kullanici_rezerve_update() returns trigger
    language plpgsql
as
$$
begin
    update rezerve
	set kime_gidecek_id = new.id
	where kime_gidecek_id = old.id;
    return new;
end;
$$;

alter function trigger_on_kullanici_rezerve_update() owner to postgres;

